import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.lovable.anaesthesiapro',
  appName: 'AnaesthesiaPro',
  webDir: 'dist/client',
  server: {
    url: 'https://app-from-html-wiz.lovable.app',
    cleartext: true,
  },
  ios: {
    contentInset: 'always',
    backgroundColor: '#070b14',
  },
};

export default config;
